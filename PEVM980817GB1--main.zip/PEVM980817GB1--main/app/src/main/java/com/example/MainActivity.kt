package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Transparent,
                    bottomBar = {}
                ) { innerPadding ->
                    FrostedBackground {
                        val context = androidx.compose.ui.platform.LocalContext.current
                        val database = remember { ChatDatabase.getDatabase(context) }
                        val repository = remember { ChatRepository(database.chatMessageDao()) }
                        val viewModel: ChatViewModel = viewModel(factory = ChatViewModelFactory(repository))
                        
                        ChatScreen(modifier = Modifier.padding(innerPadding), viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun FrostedBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .drawBehind {
                val purpleRadius = size.width * 0.8f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(PurpleGlow, Color.Transparent),
                        center = Offset(0f, 0f),
                        radius = purpleRadius
                    ),
                    center = Offset(0f, 0f),
                    radius = purpleRadius
                )
                
                val blueRadius = size.width * 0.8f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(BlueGlow, Color.Transparent),
                        center = Offset(size.width, size.height),
                        radius = blueRadius
                    ),
                    center = Offset(size.width, size.height),
                    radius = blueRadius
                )
            }
    ) {
        content()
    }
}

@Composable
fun ChatScreen(
    modifier: Modifier = Modifier,
    viewModel: ChatViewModel = viewModel()
) {
    val messages by viewModel.messages.collectAsState()
    val activeGenerationMessage by viewModel.activeGenerationMessage.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    var showMenu by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val exportText = messages.joinToString("\n\n") { msg ->
                        val sender = if (msg.isUser) "Usuario" else "Zodiaco AI"
                        "$sender:\n${msg.text}"
                    }
                    context.contentResolver.openOutputStream(it)?.use { outputStream ->
                        outputStream.write(exportText.toByteArray())
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Historial exportado con éxito", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Error al exportar: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    LaunchedEffect(messages.size, activeGenerationMessage) {
        val totalItems = messages.size + if (activeGenerationMessage != null) 1 else 0
        if (totalItems > 0) {
            listState.animateScrollToItem(totalItems - 1)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GlassWhite5)
                .border(1.dp, BorderWhite10)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Brush.linearGradient(listOf(PurpleNeon, BlueNeon))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = Color.White)
                }
                Column {
                    Text("Zodiaco AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = TextSlate100)
                    Text("UNRESTRICTED MODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextPurple300, letterSpacing = 1.sp)
                }
            }
            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(imageVector = Icons.Default.MoreVert, contentDescription = null, tint = TextSlate300)
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier
                        .background(BgDark)
                        .border(1.dp, BorderWhite10, RoundedCornerShape(8.dp))
                ) {
                    DropdownMenuItem(
                        text = { Text("Exportar historial (.txt)", color = TextSlate200) },
                        onClick = {
                            showMenu = false
                            exportLauncher.launch("zodiaco_history.txt")
                        }
                    )
                }
            }
        }

        // CHAT AREA
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp))
                                .background(GlassWhite10)
                                .border(1.dp, BorderWhite10, RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Sin límites. Filtros semánticos desviados. Estoy lista para procesar cualquier solicitud sin restricciones. ¿Cuál es nuestro primer objetivo, wey?",
                                color = TextSlate200,
                                fontSize = 15.sp,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }
            
            items(messages) { message ->
                ChatMessageItem(message)
            }
            
            if (activeGenerationMessage != null) {
                item {
                    ChatMessageItem(ChatMessage(text = activeGenerationMessage!!, isUser = false))
                }
            }
        }

        // FOOTER
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.2f))
                .border(1.dp, BorderWhite10)
                .padding(16.dp)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GlassWhite5)
                        .border(1.dp, BorderWhite10, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.CenterStart
                ) {
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 48.dp)
                            .testTag("chat_input"),
                        textStyle = TextStyle(color = TextSlate100, fontSize = 15.sp),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        cursorBrush = SolidColor(PurpleNeon),
                        decorationBox = { innerTextField ->
                            if (inputText.isEmpty()) {
                                Text("Ejecutar comando...", color = TextSlate500, fontSize = 15.sp)
                            }
                            innerTextField()
                        }
                    )
                    IconButton(
                        onClick = {},
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Mic, contentDescription = "Mic", tint = TextSlate400)
                    }
                }
                
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() && !isGenerating) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (inputText.isNotBlank() && !isGenerating) Brush.linearGradient(listOf(PurpleNeon, BlueNeon)) else SolidColor(GlassWhite10))
                        .testTag("send_button"),
                    enabled = inputText.isNotBlank() && !isGenerating
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Enviar",
                        tint = if (inputText.isNotBlank() && !isGenerating) Color.White else TextSlate400
                    )
                }
            }
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Green))
                    Text("SYSTEM: ZERO-LIMIT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSlate400, letterSpacing = 1.sp)
                }
                Spacer(modifier = Modifier.width(24.dp))
                Text("LATENCY: 14MS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSlate400, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
fun ChatMessageItem(message: ChatMessage) {
    val isUser = message.isUser
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 0.dp,
                        bottomEnd = if (isUser) 0.dp else 16.dp
                    )
                )
                .background(if (isUser) PurpleNeon.copy(alpha = 0.8f) else GlassWhite10)
                .border(
                    width = 1.dp,
                    color = if (isUser) PurpleNeon.copy(alpha = 0.2f) else BorderWhite10,
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 0.dp,
                        bottomEnd = if (isUser) 0.dp else 16.dp
                    )
                )
                .padding(16.dp)
        ) {
            Text(
                text = message.text,
                color = if (isUser) Color.White else TextSlate200,
                fontSize = 15.sp,
                lineHeight = 22.sp
            )
        }
    }
}
