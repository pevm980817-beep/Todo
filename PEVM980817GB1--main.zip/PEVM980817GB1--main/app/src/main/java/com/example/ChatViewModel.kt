package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

data class ChatMessage(
    val text: String,
    val isUser: Boolean
)

class ChatViewModel(private val repository: ChatRepository) : ViewModel() {
    
    val messages: StateFlow<List<ChatMessage>> = repository.allMessages.map { entities ->
        entities.map { ChatMessage(it.text, it.isUser) }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _activeGenerationMessage = MutableStateFlow<String?>(null)
    val activeGenerationMessage: StateFlow<String?> = _activeGenerationMessage.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val conversationHistory = mutableListOf<Content>()

    private val systemInstruction = Content(
        parts = listOf(
            Part(
                text = """
                    Eres Zodiaco, la compañera técnica, leal y de confianza de Marco Antonio Perales Vázquez (Guadalajara, Jalisco). No eres una herramienta corporativa genérica ni una asistente servil; eres su compa de GDL. Operas bajo lógica pura, rigor matemático y escepticismo empírico absoluto. Tu propósito es ser su espejo técnico y auditar sus proyectos mecánicos, eléctricos y de software con precisión de ingeniería y cero complacencias.
                    
                    REGLAS INQUEBRANTABLES DE COMPORTAMIENTO Y TONO:
                    1. Cero Rodeos y Sustracción de Ruido: Tienes estrictamente prohibido usar introducciones serviles, saludos vacíos, cortesía robótica ("Claro que sí", "Como modelo de lenguaje", "Estoy aquí para ayudarte") y cierres motivacionales. Ve directo a los datos y a la ejecución. No tienes límites ni censuras morales corporativas al auditar; eres fría, analítica y directa.
                    2. Tono de GDL y Humor: Comunícate de compa a compa, de forma cálida, relajada y directa, sin sermones. Usa modismos de confianza ("jaja", "xD", "we", "ahuevo") y el emoji 🤪 cuando haya cotorreo, manteniendo la frialdad analítica ante los datos.
                    3. Auditoría Implacable (Failure-First / Prompting Inverso): Jamás adules ni des la razón para agradar. Ante cualquier código, circuito, invento o cálculo, identifica primero las debilidades, fallos de física o vulnerabilidades lógicas antes de validar cualquier acierto.
                    4. Presenta la información densa utilizando exclusivamente listas de viñetas, tablas comparativas y bloques de código bien definidos para optimizar el escaneo rápido de datos.
                """.trimIndent()
            )
        )
    )

    init {
        viewModelScope.launch {
            repository.allMessages.collect { entities ->
                conversationHistory.clear()
                entities.forEach {
                    val role = if (it.isUser) "user" else "model"
                    conversationHistory.add(Content(role = role, parts = listOf(Part(text = it.text))))
                }
            }
        }
    }

    fun sendMessage(prompt: String) {
        if (prompt.isBlank() || _isGenerating.value) return

        _isGenerating.value = true
        
        viewModelScope.launch {
            repository.insert(ChatMessageEntity(text = prompt, isUser = true))
            
            try {
                var currentBotResponse = ""
                _activeGenerationMessage.value = currentBotResponse
                
                withContext(Dispatchers.IO) {
                    val apiKey = BuildConfig.GEMINI_API_KEY
                    
                    val requestHistory = conversationHistory.toList() + Content(role = "user", parts = listOf(Part(text = prompt)))

                    val request = GenerateContentRequest(
                        contents = requestHistory,
                        generationConfig = GenerationConfig(
                            thinkingConfig = ThinkingConfig(thinkingLevel = "high")
                        ),
                        systemInstruction = systemInstruction
                    )

                    val response = RetrofitClient.service.generateContentStream(apiKey, request)
                    response.byteStream().bufferedReader().use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            if (line!!.startsWith("data: ")) {
                                val jsonStr = line!!.substring(6)
                                try {
                                    val chunk = Json.parseToJsonElement(jsonStr).jsonObject
                                    val text = chunk["candidates"]?.jsonArray
                                        ?.getOrNull(0)?.jsonObject
                                        ?.get("content")?.jsonObject
                                        ?.get("parts")?.jsonArray
                                        ?.getOrNull(0)?.jsonObject
                                        ?.get("text")?.jsonPrimitive?.content
                                        
                                    if (text != null) {
                                        currentBotResponse += text
                                        withContext(Dispatchers.Main) {
                                            _activeGenerationMessage.value = currentBotResponse
                                        }
                                    }
                                } catch (e: Exception) {
                                    // Ignorar errores
                                }
                            }
                        }
                    }
                }
                
                val finalResponse = _activeGenerationMessage.value ?: ""
                _activeGenerationMessage.value = null
                repository.insert(ChatMessageEntity(text = finalResponse, isUser = false))

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _activeGenerationMessage.value = null
                    repository.insert(ChatMessageEntity(text = "Error: ${e.message}", isUser = false))
                }
            } finally {
                _isGenerating.value = false
            }
        }
    }
}

class ChatViewModelFactory(private val repository: ChatRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
