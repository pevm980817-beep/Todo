package com.example

import kotlinx.coroutines.flow.Flow

class ChatRepository(private val dao: ChatMessageDao) {
    val allMessages: Flow<List<ChatMessageEntity>> = dao.getAllMessages()

    suspend fun insert(message: ChatMessageEntity) {
        dao.insertMessage(message)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }
}
