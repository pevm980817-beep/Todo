package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PurpleNeon,
    secondary = BlueNeon,
    background = BgDark,
    surface = GlassWhite5,
    surfaceVariant = GlassWhite10,
    onPrimary = TextSlate100,
    onSecondary = TextSlate200,
    onBackground = TextSlate100,
    onSurface = TextSlate200,
    onSurfaceVariant = TextSlate300,
    outline = BorderWhite10
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
