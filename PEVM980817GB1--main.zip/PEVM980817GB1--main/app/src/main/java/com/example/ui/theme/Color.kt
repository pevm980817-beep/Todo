package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0F0F12)
val PurpleNeon = Color(0xFF9333EA) // purple-600
val BlueNeon = Color(0xFF2563EB)   // blue-600
val PurpleGlow = Color(0x33581C87) // purple-900/20
val BlueGlow = Color(0x331E3A8A)   // blue-900/20

val GlassWhite10 = Color(0x1AFFFFFF) // white/10
val GlassWhite5 = Color(0x0DFFFFFF)  // white/5
val BorderWhite10 = Color(0x1AFFFFFF) // white/10

val TextSlate100 = Color(0xFFF1F5F9) // slate-100
val TextSlate200 = Color(0xFFE2E8F0) // slate-200
val TextSlate300 = Color(0xFFCBD5E1) // slate-300
val TextSlate400 = Color(0xFF94A3B8) // slate-400
val TextSlate500 = Color(0xFF64748B) // slate-500
val TextPurple300 = Color(0xFFD8B4FE) // purple-300
