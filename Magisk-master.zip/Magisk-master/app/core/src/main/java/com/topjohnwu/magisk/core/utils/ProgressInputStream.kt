package com.topjohnwu.magisk.core.utils

import java.io.FilterInputStream
import java.io.FilterOutputStream
import java.io.InputStream
import java.io.OutputStream

class ProgressInputStream(
    base: InputStream,
    val progressEmitter: (Long) -> Unit
) : FilterInputStream(base) {

    private var bytesRead = 0L
    private var lastUpdate = 0L

    private fun emitProgress() {
        val cur = System.currentTimeMillis()
        if (cur - lastUpdate > 1000) {
            lastUpdate = cur
            progressEmitter(bytesRead)
        }
    }

    override fun read(): Int {
        val b = super.read()
        if (b >= 0) {
            bytesRead++
            emitProgress()
        }
        return b
    }

    override fun read(b: ByteArray): Int {
        return read(b, 0, b.size)
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val sz = super.read(b, off, len)
        if (sz > 0) {
            bytesRead += sz
            emitProgress()
        }
        return sz
    }

    override fun skip(n: Long): Long {
        val sz = super.skip(n)
        if (sz > 0) {
            bytesRead += sz
            emitProgress()
        }
        return sz
    }

    override fun close() {
        super.close()
        progressEmitter(bytesRead)
    }
}

class ProgressOutputStream(
    base: OutputStream,
    val progressEmitter: (Long) -> Unit
) : FilterOutputStream(base) {

    private var bytesWritten = 0L
    private var lastUpdate = 0L

    private fun emitProgress() {
        val cur = System.currentTimeMillis()
        if (cur - lastUpdate > 1000) {
            lastUpdate = cur
            progressEmitter(bytesWritten)
        }
    }

    override fun write(b: Int) {
        out.write(b)
        bytesWritten++
        emitProgress()
    }

    override fun write(b: ByteArray) {
        write(b, 0, b.size)
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        out.write(b, off, len)
        if (len > 0) {
            bytesWritten += len
            emitProgress()
        }
    }

    override fun close() {
        super.close()
        progressEmitter(bytesWritten)
    }
}
