package com.topjohnwu.magisk.core.utils

import android.annotation.SuppressLint
import android.app.LocaleConfig
import android.app.LocaleManager
import android.content.Intent
import android.content.res.Resources
import android.net.Uri
import android.os.Build
import android.os.LocaleList
import android.provider.Settings
import androidx.annotation.RequiresApi
import com.topjohnwu.magisk.core.AppContext
import com.topjohnwu.magisk.core.Config
import com.topjohnwu.magisk.core.R
import org.xmlpull.v1.XmlPullParser
import java.util.Locale

interface LocaleSetting {
    // The locale that is manually overridden, null if system default
    val appLocale: Locale?
    // The current active locale used in the application
    val currentLocale: Locale

    fun setLocale(tag: String)
    fun updateResource(res: Resources)

    private class Api24Impl : LocaleSetting {

        private val systemLocaleList = LocaleList.getDefault()
        private var currentLocaleList: LocaleList = systemLocaleList

        override var appLocale: Locale? = null
        override val currentLocale: Locale get() = currentLocaleList[0]

        init {
            setLocale(Config.locale)
        }

        override fun setLocale(tag: String) {
            val localeList = when {
                tag.isEmpty() -> null
                else -> LocaleList.forLanguageTags(tag)
            }
            currentLocaleList = localeList ?: systemLocaleList
            appLocale = localeList?.get(0)
            LocaleList.setDefault(currentLocaleList)
            updateResource(AppContext.resources)
            // Recreate instead of starting a new instance: MainActivity is singleTask, so
            // starting it again would deliver the intent to this instance, which is then finished
            AppContext.foregroundActivity?.recreate()
        }

        @Suppress("DEPRECATION")
        override fun updateResource(res: Resources) {
            val config = res.configuration
            config.setLocales(currentLocaleList)
            res.updateConfiguration(config, null)
        }
    }

    @RequiresApi(33)
    private class Api33Impl : LocaleSetting {

        private val lm: LocaleManager = AppContext.getSystemService(LocaleManager::class.java)

        override val appLocale: Locale?
            get() = lm.applicationLocales.let { if (it.isEmpty) null else it[0] }

        override val currentLocale: Locale
            get() = appLocale ?: lm.systemLocales[0]

        // These following methods should not be used
        override fun setLocale(tag: String) {}
        override fun updateResource(res: Resources) {}
    }

    class AppLocaleList(
        val names: Array<String>,
        val tags: Array<String>
    )

    @SuppressLint("NewApi")
    companion object {
        val available: AppLocaleList by lazy {
            val names = ArrayList<String>()
            val tags = ArrayList<String>()

            names.add(AppContext.getString(R.string.system_default))
            tags.add("")

            if (Build.VERSION.SDK_INT >= 34) {
                // Use platform LocaleConfig parser
                val config = localeConfig
                val list = config.supportedLocales ?: LocaleList.getEmptyLocaleList()
                names.ensureCapacity(list.size() + 1)
                tags.ensureCapacity(list.size() + 1)
                for (i in 0 until list.size()) {
                    val locale = list[i]
                    names.add(locale.getDisplayName(locale))
                    tags.add(locale.toLanguageTag())
                }
            } else {
                // Manually parse locale_config.xml
                val parser = AppContext.resources.getXml(R.xml.locale_config)
                while (true) {
                    when (parser.next()) {
                        XmlPullParser.START_TAG -> {
                            if (parser.name == "locale") {
                                val tag = parser.getAttributeValue(0)
                                val locale = Locale.forLanguageTag(tag)
                                names.add(locale.getDisplayName(locale))
                                tags.add(tag)
                            }
                        }
                        XmlPullParser.END_DOCUMENT -> break
                    }
                }
            }
            AppLocaleList(names.toTypedArray(), tags.toTypedArray())
        }

        @get:RequiresApi(34)
        val localeConfig: LocaleConfig by lazy {
            LocaleConfig.fromContextIgnoringOverride(AppContext)
        }

        val useLocaleManager by lazy {
            Build.VERSION.SDK_INT >= 33 &&
                    localeSettingsIntent.resolveActivity(AppContext.packageManager) != null
        }

        val localeSettingsIntent get() = Intent(
            Settings.ACTION_APP_LOCALE_SETTINGS,
            Uri.fromParts("package", AppContext.packageName, null),
        )

        val instance: LocaleSetting by lazy {
            // Initialize available locale list
            available
            if (useLocaleManager) {
                Api33Impl()
            } else {
                Api24Impl()
            }
        }
    }
}
