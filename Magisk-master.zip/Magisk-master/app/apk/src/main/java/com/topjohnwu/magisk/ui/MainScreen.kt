package com.topjohnwu.magisk.ui

import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteItem
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffoldDefaults
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteType
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.navigationevent.NavigationEventInfo
import androidx.navigationevent.compose.LocalNavigationEventDispatcherOwner
import androidx.navigationevent.compose.NavigationBackHandler
import androidx.navigationevent.compose.rememberNavigationEventDispatcherOwner
import androidx.navigationevent.compose.rememberNavigationEventState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.topjohnwu.magisk.R
import com.topjohnwu.magisk.arch.VMFactory
import com.topjohnwu.magisk.core.Info
import com.topjohnwu.magisk.core.model.module.LocalModule
import com.topjohnwu.magisk.ui.home.HomeScreen
import com.topjohnwu.magisk.ui.home.HomeViewModel
import com.topjohnwu.magisk.ui.install.InstallViewModel
import com.topjohnwu.magisk.ui.log.LogScreen
import com.topjohnwu.magisk.ui.log.LogViewModel
import com.topjohnwu.magisk.ui.module.ModuleScreen
import com.topjohnwu.magisk.ui.module.ModuleViewModel
import com.topjohnwu.magisk.ui.navigation.CollectNavEvents
import com.topjohnwu.magisk.ui.navigation.LocalNavigator
import com.topjohnwu.magisk.ui.navigation.Route
import com.topjohnwu.magisk.ui.settings.SettingsScreen
import com.topjohnwu.magisk.ui.settings.SettingsViewModel
import com.topjohnwu.magisk.ui.superuser.SuperuserScreen
import com.topjohnwu.magisk.ui.superuser.SuperuserViewModel
import kotlinx.coroutines.launch
import com.topjohnwu.magisk.core.R as CoreR

enum class Tab(val titleRes: Int, val iconRes: Int) {
    MODULES(CoreR.string.modules, R.drawable.ic_module),
    SUPERUSER(CoreR.string.superuser, CoreR.drawable.ic_superuser),
    HOME(CoreR.string.section_home, R.drawable.ic_home),
    LOG(CoreR.string.logs, R.drawable.ic_bug),
    SETTINGS(CoreR.string.settings, R.drawable.ic_settings);
}

@Composable
fun MainScreen(
    modifier: Modifier = Modifier,
    initialTab: Int = Tab.HOME.ordinal,
    requestedTab: Int? = null,
    onTabRequestHandled: () -> Unit = {},
    superuserViewModel: SuperuserViewModel? = null,
) {
    val navigator = LocalNavigator.current
    val scope = rememberCoroutineScope()
    val visibleTabs = remember {
        Tab.entries.filter { tab ->
            when (tab) {
                Tab.SUPERUSER -> Info.showSuperUser
                Tab.MODULES -> Info.env.isActive && LocalModule.loaded()
                else -> true
            }
        }
    }
    val initialPage = visibleTabs.indexOf(Tab.entries[initialTab]).coerceAtLeast(0)
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { visibleTabs.size })

    // Show a tab requested while the app is already running, e.g. by the system settings
    val currentOnTabRequestHandled by rememberUpdatedState(onTabRequestHandled)
    LaunchedEffect(requestedTab) {
        if (requestedTab == null) return@LaunchedEffect
        val page = visibleTabs.indexOf(Tab.entries[requestedTab])
        if (page >= 0) pagerState.scrollToPage(page)
        currentOnTabRequestHandled()
    }
    val fabFocusRequester = remember { FocusRequester() }
    val navModulesFocusRequester = remember { FocusRequester() }
    val navSuperuserFocusRequester = remember { FocusRequester() }
    val moduleContentFocusRequester = remember { FocusRequester() }
    val superuserContentFocusRequester = remember { FocusRequester() }
    var moduleFabAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var superuserFabAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    val isModulesTab = visibleTabs.getOrNull(pagerState.currentPage) == Tab.MODULES
    val isSuperuserTab = visibleTabs.getOrNull(pagerState.currentPage) == Tab.SUPERUSER

    val homePageIndex = remember(visibleTabs) { visibleTabs.indexOf(Tab.HOME).coerceAtLeast(0) }
    val isNotAtHome = pagerState.currentPage != homePageIndex && navigator.current() == Route.Main
    val tabBackState = rememberNavigationEventState(currentInfo = NavigationEventInfo.None)
    NavigationBackHandler(
        state = tabBackState,
        isBackEnabled = isNotAtHome,
        onBackCompleted = {
            scope.launch {
                pagerState.animateScrollToPage(homePageIndex)
            }
        }
    )

    // The collapsed rail needs 520dp (44dp top space, 96dp FAB header, 5 items, 44dp bottom) to
    // show every item. In shorter windows use the bar, like the library does below 480dp.
    val systemBars = WindowInsets.systemBars
    val railHeight = LocalWindowInfo.current.containerDpSize.height -
        with(LocalDensity.current) { (systemBars.getTop(this) + systemBars.getBottom(this)).toDp() }
    val navType = NavigationSuiteScaffoldDefaults.navigationSuiteType(currentWindowAdaptiveInfo()).let {
        if (it == NavigationSuiteType.WideNavigationRailCollapsed && railHeight < 520.dp) {
            NavigationSuiteType.ShortNavigationBarMedium
        } else it
    }
    val isBar = navType == NavigationSuiteType.ShortNavigationBarCompact ||
        navType == NavigationSuiteType.ShortNavigationBarMedium
    val showFab = (isModulesTab && moduleFabAction != null) || (isSuperuserTab && superuserFabAction != null)
    val hasFabTab = Tab.MODULES in visibleTabs || Tab.SUPERUSER in visibleTabs

    // The explicit focus wiring below assumes the FAB sits above a bottom bar, so only apply
    // it in bar mode. With a rail, the default 2D focus search works as is.
    NavigationSuiteScaffold(
        modifier = modifier.fillMaxSize(),
        navigationSuiteType = navType,
        navigationItems = {
            visibleTabs.forEachIndexed { index, tab ->
                val isModulesItem = tab == Tab.MODULES
                val isSuperuserItem = tab == Tab.SUPERUSER
                NavigationSuiteItem(
                    navigationSuiteType = navType,
                    selected = pagerState.currentPage == index,
                    onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                    modifier = Modifier
                        .then(
                            if (isModulesItem) Modifier.focusRequester(navModulesFocusRequester)
                            else if (isSuperuserItem) Modifier.focusRequester(navSuperuserFocusRequester)
                            else Modifier
                        )
                        .focusProperties {
                            if (isBar && ((isModulesTab && isModulesItem) || (isSuperuserTab && isSuperuserItem))) {
                                up = fabFocusRequester
                            }
                        },
                    icon = {
                        Icon(
                            imageVector = ImageVector.vectorResource(tab.iconRes),
                            // The label below already names the tab
                            contentDescription = null,
                        )
                    },
                    label = { Text(stringResource(tab.titleRes)) },
                )
            }
        },
        primaryActionContent = {
            // In the rail header, keep the FAB slot even when the FAB is hidden so the rail
            // items don't jump on tab switches, and center the FAB in the collapsed rail.
            // Skip the slot if no tab has a FAB (no root).
            // In bar mode, the scaffold places this slot at the end edge of the window without
            // considering insets, so pad it to keep the FAB clear of side system bars and cutouts.
            Box(
                if (isBar) Modifier.windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.End))
                else if (!hasFabTab) Modifier
                else Modifier.padding(start = 20.dp).heightIn(min = 56.dp)
            ) {
                AnimatedVisibility(
                    visible = showFab,
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut(),
                ) {
                    FloatingActionButton(
                        onClick = {
                            if (isModulesTab) moduleFabAction?.invoke()
                            else if (isSuperuserTab) superuserFabAction?.invoke()
                        },
                        // In rail mode this slot is also composed (unplaced) by the scaffold,
                        // so don't attach the focus requester there.
                        modifier = if (isBar) {
                            Modifier
                                .focusRequester(fabFocusRequester)
                                .focusProperties {
                                    up = if (isModulesTab) moduleContentFocusRequester else superuserContentFocusRequester
                                    down = if (isModulesTab) navModulesFocusRequester else navSuperuserFocusRequester
                                    right = FocusRequester.Cancel
                                }
                        } else Modifier,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        // M3: a FAB nested in the navigation rail has no elevation
                        elevation = if (isBar) FloatingActionButtonDefaults.elevation()
                            else FloatingActionButtonDefaults.bottomAppBarFabElevation(),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = stringResource(
                                if (isModulesTab) CoreR.string.module_action_install_external
                                else CoreR.string.superuser_grant
                            ),
                            modifier = Modifier.size(28.dp),
                        )
                    }
                }
            }
        },
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            beyondViewportPageCount = 0,
            // With a rail, switch tabs only through the rail, not with trackpad swipes
            userScrollEnabled = isBar,
        ) { page ->
            val isCurrentPage = pagerState.currentPage == page
            val childOwner = rememberNavigationEventDispatcherOwner(enabled = isCurrentPage)
            CompositionLocalProvider(
                LocalNavigationEventDispatcherOwner provides childOwner,
            ) {
                val tab = visibleTabs[page]
                Box(
                modifier = Modifier
                    .fillMaxSize()
                    .focusProperties {
                        onEnter = {
                            if (!isCurrentPage) {
                                cancelFocusChange()
                            }
                        }
                        onExit = {
                            // With a rail, nothing is below the page, so don't let DPAD_DOWN
                            // jump into the rail; leaving to the rail is done with DPAD_LEFT.
                            val dir = requestedFocusDirection
                            if (dir == FocusDirection.Up ||
                                (!isBar && dir == FocusDirection.Down) ||
                                (isBar && (dir == FocusDirection.Left || dir == FocusDirection.Right))
                            ) {
                                cancelFocusChange()
                            }
                        }
                        if (isBar && (tab == Tab.MODULES || tab == Tab.SUPERUSER)) {
                            down = fabFocusRequester
                        }
                    }
                    .focusGroup()
            ) {
                when (visibleTabs[page]) {
                    Tab.HOME -> {
                        val vm: HomeViewModel = viewModel(factory = VMFactory)
                        val installVm: InstallViewModel = viewModel(factory = VMFactory)
                        LaunchedEffect(isCurrentPage) {
                            if (isCurrentPage) vm.startLoading()
                        }
                        CollectNavEvents(vm, navigator)
                        CollectNavEvents(installVm, navigator)
                        HomeScreen(vm, installVm)
                    }
                    Tab.SUPERUSER -> {
                        val activity = LocalActivity.current as? ComponentActivity
                        val vm: SuperuserViewModel = superuserViewModel
                            ?: if (activity != null) {
                                viewModel(viewModelStoreOwner = activity, factory = VMFactory)
                            } else {
                                viewModel(factory = VMFactory)
                            }
                        LaunchedEffect(isCurrentPage) {
                            if (isCurrentPage) vm.startLoading()
                        }
                        CollectNavEvents(vm, navigator)
                        SuperuserScreen(
                            viewModel = vm,
                            onRegisterFab = { superuserFabAction = it },
                            isFabAtBottom = isBar,
                            contentFocusRequester = superuserContentFocusRequester,
                        )
                    }
                    Tab.LOG -> {
                        val vm: LogViewModel = viewModel(factory = VMFactory)
                        LaunchedEffect(isCurrentPage) {
                            if (isCurrentPage) vm.startLoading()
                        }
                        LogScreen(vm)
                    }
                    Tab.MODULES -> {
                        val vm: ModuleViewModel = viewModel(factory = VMFactory)
                        LaunchedEffect(isCurrentPage) {
                            if (isCurrentPage) vm.startLoading()
                        }
                        CollectNavEvents(vm, navigator)
                        ModuleScreen(
                            viewModel = vm,
                            onRegisterFab = { moduleFabAction = it },
                            isFabAtBottom = isBar,
                            contentFocusRequester = moduleContentFocusRequester,
                        )
                    }
                    Tab.SETTINGS -> {
                        val vm: SettingsViewModel = viewModel(factory = VMFactory)
                        CollectNavEvents(vm, navigator)
                        SettingsScreen(vm)
                    }
                }
            }
            }
        }
    }
}
