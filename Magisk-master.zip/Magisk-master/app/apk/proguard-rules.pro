# Excessive obfuscation
-flattenpackagehierarchy
